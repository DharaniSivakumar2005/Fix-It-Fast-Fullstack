import React, { useEffect, useMemo, useState } from 'react';
import { adminAPI, apiHelpers, complaintsAPI } from '../../../services/api';
import './AssignedStatus.css';

// Admin page: Assigned Complaint Status (short: Assigned Status)
const AssignedStatus = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState(''); // '', 'Assigned', 'In Progress', 'Completed'
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [progressMap, setProgressMap] = useState({}); // { complaintId: { before:[], after:[] } }
  const [modalImage, setModalImage] = useState('');

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      // Fetch complaints scoped to the admin's city on the backend (no city sent from frontend)
      const { data } = await adminAPI.getAllComplaints({ limit: 200 });
      const list = data?.complaints || [];
      // We show only items that have been assigned (assumption: status transitions after assignment)
      const assignedLikeStatuses = ['Assigned', 'In Progress', 'Resolved'];
      const filtered = list.filter(c => assignedLikeStatuses.includes(c.status));
      setItems(filtered);

      // Fetch progress images for these complaints (best-effort)
      const entries = await Promise.all(filtered.map(async (c) => {
        try {
          const res = await complaintsAPI.getProgressImages(c._id);
          return [c._id, res.data?.images || { before: [], after: [] }];
        } catch (_) {
          return [c._id, { before: [], after: [] }];
        }
      }));
      const map = Object.fromEntries(entries);
      setProgressMap(map);
    } catch (e) {
      setError(apiHelpers.handleError(e).message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    if (!autoRefresh) return;
    const id = setInterval(load, 10000); // poll every 10s to reflect labour updates
    return () => clearInterval(id);
  }, [autoRefresh]);

  const view = useMemo(() => {
    let data = [...items];
    if (status) data = data.filter(c => (c.status || '').toLowerCase() === status.toLowerCase());
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(c =>
        String(c._id || '').toLowerCase().includes(q) ||
        String(c.title || '').toLowerCase().includes(q) ||
        String(c.category || '').toLowerCase().includes(q) ||
        String(c.location || '').toLowerCase().includes(q) ||
        String(c.assignedTo?.name || c.labour?.name || '').toLowerCase().includes(q)
      );
    }
    return data;
  }, [items, search, status]);

  return (
    <div className="as-container">
      <div className="as-header">
        <div>
          <h1>Assigned Status</h1>
          <p>Live view of complaints after assignment. Changes made by labour (In Progress ➜ Completed) are reflected here.</p>
        </div>
        <div className="as-actions">
          <input className="as-input" placeholder="Search (id, title, category, location, labour)" value={search} onChange={(e)=>setSearch(e.target.value)} />
          <select className="as-input" value={status} onChange={(e)=>setStatus(e.target.value)}>
            <option value="">All Statuses</option>
            <option value="Assigned">Assigned</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>
          <button className="as-btn" onClick={load} disabled={loading}>{loading ? 'Loading...' : 'Refresh'}</button>
          <label className="as-toggle">
            <input type="checkbox" checked={autoRefresh} onChange={(e)=>setAutoRefresh(e.target.checked)} /> Auto refresh
          </label>
        </div>
      </div>

      {error && <div className="as-alert as-error">❌ {error}</div>}

      <div className="as-table-wrap">
        <table className="as-table">
          <thead>
            <tr>
              <th>Complaint ID</th>
              <th>Title</th>
              <th>Category</th>
              <th>Location</th>
              <th>Assigned To</th>
              <th>Status</th>
              <th>Before & After</th>
              <th>Updated</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan="7" className="as-cell-center">Loading...</td></tr>
            )}
            {!loading && view.length === 0 && !error && (
              <tr><td colSpan="7" className="as-cell-center">No assigned complaints found.</td></tr>
            )}
            {!loading && view.map((c) => {
              const imgs = progressMap[c._id] || { before: [], after: [] };
              const beforeUrl = imgs.before?.[0]?.imageUrl || '';
              const afterUrl = imgs.after?.[0]?.imageUrl || '';
              const wip = imgs.before?.length > 0 && imgs.after?.length === 0;
              const done = imgs.before?.length > 0 && imgs.after?.length > 0;
              return (
                <tr key={c._id}>
                  <td>{c._id}</td>
                  <td>{c.title}</td>
                  <td>{c.category || '-'}</td>
                  <td>{c.location || '-'}</td>
                  <td>{c.assignedTo?.name || c.labour?.name || c.assignedTo?.email || '-'}</td>
                  <td>
                    <span className={`as-badge as-${String(c.status || '').toLowerCase().replace(/\s+/g,'-')}`}>{c.status}</span>
                    {wip && <div className="as-progress as-wip">Before uploaded</div>}
                    {done && <div className="as-progress as-done">Before & After uploaded</div>}
                  </td>
                  <td>
                    <div className="as-bna">
                      <div className="as-thumb" onClick={()=> beforeUrl && setModalImage(beforeUrl)}>
                        {beforeUrl ? (
                          <img src={beforeUrl} alt="before" />
                        ) : (
                          <div className="as-ph">Before</div>
                        )}
                      </div>
                      <div className="as-sep">→</div>
                      <div className="as-thumb" onClick={()=> afterUrl && setModalImage(afterUrl)}>
                        {afterUrl ? (
                          <img src={afterUrl} alt="after" />
                        ) : (
                          <div className="as-ph">After</div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td>{new Date(c.updatedAt || c.assignedAt || c.createdAt).toLocaleString()}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {modalImage && (
        <div className="as-modal" onClick={()=>setModalImage('')}>
          <div className="as-modal-card" onClick={(e)=>e.stopPropagation()}>
            <button className="as-modal-close" onClick={()=>setModalImage('')}>✕</button>
            <img src={modalImage} alt="full" style={{ maxWidth: '90vw', maxHeight: '80vh' }} />
          </div>
        </div>
      )}
    </div>
  );
};

export default AssignedStatus;
