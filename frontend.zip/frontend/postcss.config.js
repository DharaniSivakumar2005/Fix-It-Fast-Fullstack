export default {
  plugins: {
    autoprefixer: {},
  },
}
